#!/bin/bash

if ! command -v python3 &> /dev/null
then
    echo "Python3 is not installed. Please install Python3 and try again."
    exit
fi

if ! python3 -m pip install -r requirements.txt
then
    echo "Failed to install required packages from requirements.txt."
    exit
fi

SCRIPT_NAME="MyoPillarSense_GUI.py"
if ! python3 "$SCRIPT_NAME"
then
    echo "Failed to run $SCRIPT_NAME."
    exit
fi
